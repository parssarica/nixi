#ifndef __SVE_DETECTION__
#define __SVE_DETECTION__

uint64_t sve_cntb(void);

#endif
