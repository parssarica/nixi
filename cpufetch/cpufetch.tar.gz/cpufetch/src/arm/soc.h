#ifndef __SOC_ARM__
#define __SOC_ARM__

#include "../common/cpu.h"
#include "../common/soc.h"
#include <stdint.h>

struct system_on_chip* get_soc(struct cpuInfo* cpu);

#endif
