#ifndef __FREQ_NO_VECTOR__
#define __FREQ_NO_VECTOR__

void* compute_nov(void * pthread_arg);

#endif
