#ifndef __FREQ_AVX__
#define __FREQ_AVX__

void* compute_avx(void * pthread_arg);

#endif
