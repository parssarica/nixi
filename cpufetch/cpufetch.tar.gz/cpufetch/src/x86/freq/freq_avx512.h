#ifndef __FREQ_AVX512__
#define __FREQ_AVX512__

void* compute_avx512(void * pthread_arg);

#endif
