#ifndef __COMMON_FREQ__
#define __COMMON_FREQ__

int64_t measure_max_frequency(uint32_t core);

#endif
